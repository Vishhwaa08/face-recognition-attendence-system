import re
import cv2
from config import DATASET_DIR, CASCADE_PATH, CAMERA_INDEX, SAMPLES_PER_STUDENT
from utils import ensure_dirs, load_face_cascade

def main():
    student_id = input("Enter student ID (letters/numbers/_/- only): ").strip()
    name = input("Enter student name: ").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,30}", student_id):
        print("Invalid ID. Use 1-30 letters, numbers, underscore or hyphen.")
        return
    if not name:
        print("Name cannot be empty.")
        return

    ensure_dirs(DATASET_DIR)
    student_dir = DATASET_DIR / student_id
    student_dir.mkdir(parents=True, exist_ok=True)
    cascade = load_face_cascade(CASCADE_PATH)
    cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        print("Cannot open webcam. Check camera connection or CAMERA_INDEX in config.py.")
        return

    count = 0
    print("Look at the camera. Press q to stop.")
    try:
        while count < SAMPLES_PER_STUDENT:
            ok, frame = cap.read()
            if not ok:
                print("Could not read from webcam.")
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
            for (x, y, w, h) in faces[:1]:
                face = cv2.resize(gray[y:y+h, x:x+w], (200, 200))
                count += 1
                cv2.imwrite(str(student_dir / f"{count:03d}.jpg"), face)
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, f"Samples: {count}/{SAMPLES_PER_STUDENT}",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
                break
            cv2.imshow("Register Face - press q to quit", frame)
            if cv2.waitKey(100) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()

    # Store name separately so it survives model retraining.
    import csv
    names_file = DATASET_DIR / "students.csv"
    records = {}
    if names_file.exists():
        with names_file.open("r", newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                records[row["Student ID"]] = row["Name"]
    records[student_id] = name
    with names_file.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["Student ID", "Name"])
        writer.writeheader()
        for sid, sname in sorted(records.items()):
            writer.writerow({"Student ID": sid, "Name": sname})
    print(f"Saved {count} face samples for {name} ({student_id}).")

if __name__ == "__main__":
    main()
