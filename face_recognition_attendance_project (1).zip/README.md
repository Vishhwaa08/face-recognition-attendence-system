# Face Recognition Attendance System (Python)

A local desktop project using OpenCV LBPH face recognition. It supports student registration, model training, live recognition, and CSV/Excel attendance export.

## Requirements
- Python 3.9+
- Webcam
- Windows/macOS/Linux

## Setup
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## Run
1. Register a student:
   ```bash
   python register_face.py
   ```
   Enter a unique student ID and name. Look toward the webcam; press `q` to stop after capturing enough samples.
2. Train the recognizer:
   ```bash
   python train_model.py
   ```
3. Start attendance:
   ```bash
   python attendance.py
   ```
   Press `q` to close the camera. Attendance is saved in `attendance/attendance.csv` and `attendance/attendance.xlsx`.

## Notes
- Use only with informed consent. Provide a non-biometric attendance alternative.
- Keep `dataset/`, `trainer/`, and `attendance/` private; they contain personal/biometric data.
- Recognition accuracy depends on lighting, camera quality, pose, and training samples. Verify attendance records rather than treating recognition as definitive.
- This demo uses LBPH from `opencv-contrib-python`. Do not install both `opencv-python` and `opencv-contrib-python` in the same environment.
