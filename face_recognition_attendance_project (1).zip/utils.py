import csv
from datetime import datetime
from pathlib import Path
import cv2
import pandas as pd

def load_face_cascade(path):
    cascade = cv2.CascadeClassifier(str(path))
    if cascade.empty():
        raise RuntimeError("Could not load Haar cascade file.")
    return cascade

def ensure_dirs(*paths):
    for path in paths:
        Path(path).mkdir(parents=True, exist_ok=True)

def append_attendance(directory, student_id, name):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    csv_path = directory / "attendance.csv"
    xlsx_path = directory / "attendance.xlsx"
    now = datetime.now()
    row = {
        "Student ID": str(student_id),
        "Name": name,
        "Date": now.strftime("%Y-%m-%d"),
        "Time": now.strftime("%H:%M:%S"),
    }

    # One entry per student per day.
    existing = set()
    if csv_path.exists():
        with csv_path.open("r", newline="", encoding="utf-8") as f:
            for item in csv.DictReader(f):
                existing.add((item.get("Student ID"), item.get("Date")))
    if (str(student_id), row["Date"]) in existing:
        return False

    write_header = not csv_path.exists()
    with csv_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=row.keys())
        if write_header:
            writer.writeheader()
        writer.writerow(row)

    try:
        df = pd.read_csv(csv_path)
        df.to_excel(xlsx_path, index=False)
    except Exception as exc:
        print(f"Warning: Excel export failed ({exc}); CSV was saved.")
    return True
