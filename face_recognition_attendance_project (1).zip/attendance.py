import csv
import cv2
from config import (CASCADE_PATH, CAMERA_INDEX, MODEL_PATH, LABELS_PATH,
                    ATTENDANCE_DIR, RECOGNITION_THRESHOLD)
from utils import load_face_cascade, append_attendance

def main():
    if not hasattr(cv2, "face"):
        raise RuntimeError("LBPH unavailable. Install opencv-contrib-python.")
    if not MODEL_PATH.exists() or not LABELS_PATH.exists():
        print("Trained model not found. Run train_model.py first.")
        return

    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(str(MODEL_PATH))
    with LABELS_PATH.open("r", newline="", encoding="utf-8") as f:
        labels = {int(r["Label"]): (r["Student ID"], r["Name"]) for r in csv.DictReader(f)}

    cascade = load_face_cascade(CASCADE_PATH)
    cap = cv2.VideoCapture(CAMERA_INDEX)
    if not cap.isOpened():
        print("Cannot open webcam. Check camera connection or CAMERA_INDEX in config.py.")
        return

    print("Attendance started. Press q to quit.")
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
            for (x, y, w, h) in faces:
                crop = cv2.resize(gray[y:y+h, x:x+w], (200, 200))
                label, confidence = recognizer.predict(crop)
                if confidence <= RECOGNITION_THRESHOLD and label in labels:
                    sid, name = labels[label]
                    marked = append_attendance(ATTENDANCE_DIR, sid, name)
                    status = "Attendance marked" if marked else "Already marked today"
                    color = (0, 200, 0)
                    display = f"{name} | {status}"
                else:
                    display, color = "Unknown", (0, 0, 255)
                cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                cv2.putText(frame, display, (x, max(25, y-10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
            cv2.imshow("Face Recognition Attendance - press q to quit", frame)
            if cv2.waitKey(10) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()
    print(f"Attendance files are in: {ATTENDANCE_DIR}")

if __name__ == "__main__":
    main()
