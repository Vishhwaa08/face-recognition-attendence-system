import csv
import cv2
import numpy as np
from config import DATASET_DIR, TRAINER_DIR, MODEL_PATH, LABELS_PATH
from utils import ensure_dirs

def main():
    if not hasattr(cv2, "face"):
        raise RuntimeError("LBPH is unavailable. Install opencv-contrib-python (not opencv-python).")
    if not DATASET_DIR.exists():
        print("No dataset found. Run register_face.py first.")
        return

    students_file = DATASET_DIR / "students.csv"
    if not students_file.exists():
        print("Student details not found. Register at least one student.")
        return
    with students_file.open("r", newline="", encoding="utf-8") as f:
        names = {row["Student ID"]: row["Name"] for row in csv.DictReader(f)}

    faces, labels, label_map = [], [], {}
    label = 0
    for student_id in sorted(names):
        folder = DATASET_DIR / student_id
        samples = list(folder.glob("*.jpg")) if folder.exists() else []
        if not samples:
            continue
        label_map[label] = (student_id, names[student_id])
        for path in samples:
            image = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
            if image is not None:
                faces.append(cv2.resize(image, (200, 200)))
                labels.append(label)
        label += 1

    if not faces:
        print("No face samples found. Run register_face.py.")
        return

    ensure_dirs(TRAINER_DIR)
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.train(faces, np.array(labels, dtype=np.int32))
    recognizer.write(str(MODEL_PATH))
    with LABELS_PATH.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Label", "Student ID", "Name"])
        for key, value in label_map.items():
            writer.writerow([key, value[0], value[1]])
    print(f"Training complete. {len(faces)} images from {len(label_map)} students.")
    print(f"Model saved to: {MODEL_PATH}")

if __name__ == "__main__":
    main()
