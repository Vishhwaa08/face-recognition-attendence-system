from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATASET_DIR = BASE_DIR / "dataset"
TRAINER_DIR = BASE_DIR / "trainer"
ATTENDANCE_DIR = BASE_DIR / "attendance"
MODEL_PATH = TRAINER_DIR / "lbph_model.yml"
LABELS_PATH = TRAINER_DIR / "labels.csv"
CASCADE_PATH = BASE_DIR / "haarcascade_frontalface_default.xml"

SAMPLES_PER_STUDENT = 60
CAMERA_INDEX = 0
RECOGNITION_THRESHOLD = 65.0  # Lower LBPH confidence distance is better.
